# Question 4
create database order_details;
use order_details;
create table orders(
order_id int Primary key auto_increment,
customer_name varchar(60) not null,
product varchar(40),
amount int check(amount<=50000) default 50000
);
insert into orders(order_id,customer_name,product) values(113,'Nml','TV');
insert into orders values(114,'Ghm','Smartphone',40000);
insert into orders values(115,'Rty','Smartphone',30000);
select * from orders where amount>10000;
select * from orders where product='Laptop';
select distinct product from orders;
select * from orders where amount between 8000 and 30000 order by amount;
select product,count(product) from orders group by product;
select max(amount) as max_amount from orders;
drop table if exists orders;


# Question 5
create table library3(
book_id  int primary key auto_increment,
title varchar(50) unique not null,
author varchar(50),
price int  default 500 check(price<=1500)
);
insert into library3(book_id,title,author) values(113,'Lost','Den');
insert into library3 values(114,'Kid','Lure',1400);
insert into library3 values(115,'Lion','Sun',1000);
select * from library3 where price>10000;
select * from library3 where author='RK Narayan';
select distinct author from library3;
select title from library3 order by price desc limit 2;
select * from library3 where price between 400 and 1000 order by price;
select book_id,author,count(book_id) from library3 group by book_id,author;
select book_id from library3 order by price limit 1;
drop table library3;




