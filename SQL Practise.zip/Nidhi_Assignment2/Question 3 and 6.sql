# Question 3
create database hospital;
use hospital;
create table hospital_details(
patient_id int Primary key auto_increment,
patient_name varchar(60) not null,
disease varchar(30),
bill_amount int check(bill_amount<=200000) default 50000
);
insert into hospital_details(patient_id,patient_name,disease) values(113,'Nml','Phenylketonuria');
insert into hospital_details values (114,'Sql','Aids',50000);
insert into hospital_details values(115,'Poi','Sickle cell anemia',100000);
select * from hospital_details where bill_amount>50000;
select * from hospital_details where bill_amount<10000;
select distinct disease from hospital_details;
select patient_name from hospital_details order by bill_amount limit 2;
select patient_name from hospital_details where bill_amount between 20000 and 80000 order by bill_amount;
select patient_name,count(patient_name) from hospital_details group by patient_name;
select patient_name from hospital_details order by bill_amount limit 1;
drop table hospital_detials;


# Question 6
create table teacher(
teacher_id int primary key auto_increment,
teacher_name varchar(60) not null,
subject varchar(30),
salary int check(salary<=80000) default 50000);
insert into teacher(teacher_id,teacher_name,subject) values(113,'Nml','AI');
insert into teacher values (114,'Sql','Power BI',60000);
insert into teacher values(115,'Poi','Python',70000);
select * from teacher where salary>50000;
select * from teacher where subject='Maths' or salary>30000;
select distinct subject from  teacher;
select teacher_name from teacher order by salary desc limit 1;
select teacher_name from teacher where salary between 20000 and 70000 order by salary;
select teacher_name,subject,count(teacher_name) from teacher group by teacher_name,subject;
select teacher_name from teacher order by salary limit 1; 
drop table teacher;


