# Question 9
create database chidiya;
use chidiya;
Create table shop1(
item_id  int Primary Key Auto_Increment,
item_name varchar(60) unique not null,
supplier varchar(40),
price int check (price <= 20000) default 15000);
insert into shop1 (item_id,item_name,supplier) values(113,'Lost','Den');
insert into shop1 values(114,'Kid','Lure',14000);
insert into shop1 values(115,'Lion','Sun',20000);
select * from shop1 where price>1500;
select * from shop1 where supplier='ABC Ltd' or price<1500;
select distinct supplier from shop1;
select * from shop1 where price between 7000 and 16000 order by price;
select supplier,price,count(price) from shop1 group by supplier,price;
select item_name from shop1 order by price limit 1;
drop table shop1;

#Question 10
Create table flights(
flight_id int Primary Key Auto_Increment,
airline varchar(60) not null,
source varchar(30),
destination varchar(30),
fare int check (fare <= 20000) default 15000);
insert into flights (flight_id,airline,source,destination) values(113,'Lost','Den','htd');
insert into flights values(114,'Kid','Lure','bop',14000);
insert into flights values(115,'Lion','Sun','kly',20000);
select * from flights where fare>10000;
select * from flights where source='Delhi' or fare<5000;
select distinct airline from flights;
select airline from flights order by fare desc limit 2;
select * from flights where fare between 8000 and 15000 order by fare;
select source,flight_id,count(flight_id) from flights group by flight_id,source;
select flight_id from flights order by fare desc limit 1;
drop table if exists flights;

