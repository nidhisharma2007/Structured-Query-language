#  Question 1
create database ufo_reverse4;
use ufo_reverse4;
create table Company4(
emp_id int primary key auto_increment,
emp_name varchar(50) not null,
department varchar(20),
Salary int default 20000 check(Salary>=20000)
);
insert into Company4 (emp_id,emp_name,department) values(113,'Abc','AI');
insert into Company4 values(114,'Pwt','Animation',50000);
insert into Company4 values(115,'Hji','Music',60000);
Select emp_name from Company4 where Salary>50000;
select emp_name from Company4 where salary<30000;
select distinct department from Company4;
select emp_id from Company4 order by Salary desc limit 2;
select emp_name from Company4 where salary between 25000 and 60000;
select department,count(*) from Company4 group by department;
select emp_name,salary,department from Company4 order by Salary desc limit 1;
drop table Company4;

# Question 8
Create table bankaccount(
acc_id int Primary Key Auto_Increment,
holder_name varchar(60) not null,
branch varchar(30),
balance int check (balance >= 1000) default 1500);
insert into bankaccount (acc_id,holder_name,branch) values(113,'Abc','fianace');
insert into bankaccount values(114,'Pwt','accounts',10000);
insert into bankaccount values(115,'Hji','eco',60000);
select * from bankaccount where balance>20000;
select * from bankaccount where branch='Delhi' or balance<50000;
select distinct branch from bankaccount;
use ufo_reverse4;
SELECT * FROM bankaccount ORDER BY balance desc limit 1;
select * from bankaccount where balance between 10000 and 30000 order by balance;
select branch,balance,count(balance) from bankaccount group by branch,balance;
select branch from bankaccount order by balance limit 1;
drop table bankaccount;

