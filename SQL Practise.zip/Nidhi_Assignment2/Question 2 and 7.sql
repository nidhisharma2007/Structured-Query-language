# Question 2
create database students;
use students;
create table students_detail(
course_id int primary key auto_increment,
course_name varchar(60) unique,
duration int not null,
fees int check(fees<=100000) default 20000
);
insert into students_detail(course_id,course_name,duration) values(113,'Abc',3);
insert into students_details values(114,'Trt',4,70000);
insert into students_details values(115,'Uip',6,60000);
select * from students_details where duration>6;
select * from students_details where fees<50000;
select distinct duration,course_name from students_details;
select course_name from students_details order by fees limit 1;
select course_name from students_details where duration between 6 and 12 order by fees;
select course_name,count(course_name) from students_details group by course_name;
select course_name from students_details order by fees limit 1;
drop table student_details;

# Question 7
Create table Cinema(
movie_id int Primary Key Auto_Increment,
movie_name varchar(60) unique not null,
language varchar(20),
rating int check (rating <= 10) default 8);
insert into Cinema(movie_id,movie_name,language) values(113,'Abc','Hindi');
insert into Cinema values(114,'Trt','Bhojpuri',9);
insert into Cinema values(115,'Uip','English',7);
select * from Cinema where rating>7;
select * from Cinema where language='Hindi' or rating<5;
select distinct language from Cinema;
select movie_name from Cinema order by rating desc limit 2;
select movie_name from Cinema where rating between 5 and 9 order by rating;
select movie_name,language,count(movie_name) from Cinema group by movie_name,language;
select movie_name from Cinema order by rating desc limit 1; 
drop table if exists Cinema;

